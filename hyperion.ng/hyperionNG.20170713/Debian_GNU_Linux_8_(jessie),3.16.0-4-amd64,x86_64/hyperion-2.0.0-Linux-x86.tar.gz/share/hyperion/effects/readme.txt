This folder is for your personal effects.
If you want to modify effect parameters only, use the effect configurator from the webinterface.
If you want to develop your own effects, place python and json files here.

If you need examples or want to modify python file for hyperion included effect- You can export the included effects:

hyperiond --export-effects <existing path to export>

e.g.

hyperiond --export-effects /usr/share/hyperion/effects
